<?php
header("location:page/index.php");
?>